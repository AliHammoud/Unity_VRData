﻿using UnityEngine;
using System.Collections;
using SimpleJSON;
using VRDataLib.Data;

public class DataGrabber : MonoBehaviour {

	void Start() {



	}

	/*
	private POSTScript a;
	private string theData;

	void Start () {

		a = GetComponent<POSTScript> ();

		EasyJSON.createFile ("test.json");
		EasyJSON.appendJSON ("scene", "sceneName");
		EasyJSON.appendJSON ("poi", "poiValue");
		EasyJSON.appendJSON ("interaction", "interactionType");
		EasyJSON.appendJSON ("timestamp", "213456");
		EasyJSON.closeJSON ();
		//EasyJSON.debugData ();

		//theData = EasyJSON.strListToStr (EasyJSON.getData ());
		//theData = "[{\"scene\":1,\"poi\":1,\"pos\":{\"x\":1,\"y\":2,\"z\":3},\"rot\":{\"x\":1,\"y\":2,\"z\":3},\"scale\":{\"x\":1,\"y\":2,\"z\":3},\"duration\":7.4,\"interaction\":\"click\",\"timestamp\":1452694269}]";
		theData = JSONArray.Parse (EasyJSON.strListToStr (EasyJSON.getData ()));
		StartCoroutine ("sendData");



	}

	IEnumerator sendData() {
		
		StartCoroutine(a.postInit());
		yield return new WaitForSeconds (3.0f);
		StartCoroutine(a.postData (theData));
	}

	void Update () {
	


	}
	*/
}
