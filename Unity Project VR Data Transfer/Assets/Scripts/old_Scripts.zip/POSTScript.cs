﻿using UnityEngine;
using System.Collections;

public class POSTScript : MonoBehaviour {
	/*
	public string 
		URL_INIT = "https://www.euriskomobility.me/vr/api/initialize_session.php",
		URL_DATA = "https://www.euriskomobility.me/vr/api/submit_data.php";

	private string msg;

	public IEnumerator postInit(){

		yield return null;

		WWWForm form = new WWWForm ();
		form.AddField ("appid", "123");
		form.AddField ("deviceid", "456");

		WWW www = new WWW(URL_INIT, form);
		StartCoroutine(HTTPRequest(www));
	}

	public IEnumerator postData(string _data){

		yield return null;

		WWWForm form = new WWWForm ();
		form.AddField ("data", _data);
		form.AddField ("appid", "123");
		form.AddField ("userid", "22");
		form.AddField ("sessionid", msg);

		WWW www = new WWW(URL_DATA, form);
		StartCoroutine(HTTPRequest(www));
	}

	IEnumerator HTTPRequest(WWW www){

		yield return www;

		// check for errors
		if (www.error == null)
		{
			msg = www.text;
			Debug.Log("WWW Ok!: " + www.text);
		} else {
			Debug.Log("WWW Error: "+ www.error);
		}   

	}
	*/

}