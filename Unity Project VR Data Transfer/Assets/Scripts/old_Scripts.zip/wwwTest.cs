﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;

public class wwwTest : MonoBehaviour {

	public string initURL = "https://www.euriskomobility.me/vr/api/initialize_session.php";
	private string postData = "{ 'appid': 111, 'deviceid': 222 }";

	void Start () {

		StartCoroutine ("postRequest");

	}

	private WWW sendPostRequest (string url, string data) {

		Dictionary<string, string> headers = new Dictionary<string, string> ();
		headers.Add("Content-Type", "application/json");
		byte[] encodedPostData = Encoding.ASCII.GetBytes(data.ToCharArray());

		WWW request = new WWW (url, encodedPostData, headers);

		return request;

	}

	IEnumerator postRequest () {

		WWW request = sendPostRequest(initURL,postData);
		yield return request;

		if (request.error != null) {

			Debug.Log ("request error: " + request.error);
		} else {

			Debug.Log ("request succes");
			Debug.Log ("Data: " + request.text);

		}

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
