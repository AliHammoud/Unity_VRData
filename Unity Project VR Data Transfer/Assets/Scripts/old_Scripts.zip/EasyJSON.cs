﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;

#region JSON
public static class EasyJSON {

	private static string 
		fileName = "data.json",
		dir = @"Assets\" + fileName;

	private static List <string> data = new List <string> ();

	public static void appendJSON <T> (T _key, T _value) {

		try {

			insertTuple(_key, _value);

		} catch (System.Exception e) {

			Debug.LogWarning("Encountered when appending: " + e);

		}

	}

	public static void createFile (string _fileName) {

		dir = @"Assets\" + _fileName;

		if (File.Exists(dir)) {

			//Delete existing file
			File.Delete(dir);

		}

		//open the first brace in JSON file
		data.Add ("[{");
	}

	private static void insertTuple <T> (T _key, T _value) {

		int index = 0;
		//Update an exisitng key
		foreach (string str in data) {
			
			if (str.Contains (_key as string)) {
				
				updateValue (_key, _value, index);

			} else {

				string tupleText = makeTuple (_key, _value);
				data.Add (tupleText);

			}
			index++;

		}
	}

	private static string makeTuple <T> ( T _key, T _value) {

		string tuple = 

			('"').ToString () + _key as string + ('"').ToString () +
			":" +
			('"').ToString () + _value as string + ('"').ToString () +
			", ";

		return tuple;

	}

	private static void updateValue <T> (T _key, T _value, int _index) {
		
		string updatedTuple = makeTuple (_key, _value);
		data.RemoveAt (_index);
		data.Insert (_index - 1, updatedTuple);

	}

	public static void closeJSON () {

		//remove the "," in the end
		string lastLine = data.ElementAt (data.Count - 1);
		lastLine = lastLine.Remove (lastLine.IndexOf (','));

		data.RemoveAt (data.Count - 1);
		data.Add (lastLine);
		data.Add ("}]");

		File.WriteAllLines(dir, data.ToArray());

	}

	public static List<string> getData () {

		return data;

	}

	public static void debugData() {

		Debug.Log ("######## JSON Data Debug ##########");
		foreach (string str in data) {

			Debug.Log (str);

		}
		Debug.Log ("##############################");

	}

	public static string strListToStr(List <string> _list) {

		string str = "";

		foreach (string s in _list) {
			str += s;
		}

		Debug.Log (str);

		return str;

	}

}
#endregion JSON;